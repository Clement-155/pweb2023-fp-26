<?php

header("Location: ./app/views/event/index.php", true, 301);

exit();

?>