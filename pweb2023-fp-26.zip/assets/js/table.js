$(function() {
    $(document).ready(function() {
      $('#example').dataTable( {
        "language": {
        "infoEmpty": "No entries to show"
        }
        } );

})
});
  